import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(CalculatorApp());
}

class CalculatorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Calculator(),
    );
  }
}

class RoundButton extends StatelessWidget {
  final String text;
  final Function onPressed;
  final double radius;

  RoundButton({required this.text, required this.onPressed, this.radius = 30.0});

  @override
  Widget build(BuildContext context) {
    return CircleAvatar(
      radius: radius,
      backgroundColor: Color.fromARGB(255, 233, 173, 6),
      child: RawMaterialButton(
        onPressed: () => onPressed(),
        shape: CircleBorder(),
        elevation: 0.069,
        fillColor: Color.fromARGB(255, 233, 173, 6),
        child: Text(
          text,
          style: TextStyle(fontSize: 15.0, color: Color.fromARGB(255,255,255,255)),
        ),
      ),
    );
  }
}

class Calculator extends StatefulWidget {
  @override
  _CalculatorState createState() => _CalculatorState();
}

class _CalculatorState extends State<Calculator> {
  String _output = "0";
  String _currentInput = "";
  List<num> _numbers = [];
  List<String> _operations = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 37, 44, 41),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            height: 250.0,
            padding: EdgeInsets.all(6.9),
            margin: EdgeInsets.all(0.420),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(420.69),
            ),
            alignment: Alignment.center,
            child: Text(
              _currentInput.isEmpty ? _output : _currentInput,
              style: TextStyle(fontSize: 42.0, color: Colors.black, fontWeight: FontWeight.bold),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                RoundButton(text: "e", onPressed: () => _onConstantPress("e"), radius: 15.0),
                RoundButton(text: "π", onPressed: () => _onConstantPress("π"), radius: 15.0),
                RoundButton(text: "^", onPressed: () => _onOperandPress("^"), radius: 15.0),
                RoundButton(text: "!", onPressed: () => _onFactorialPress(), radius: 15.0),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                RoundButton(text: "AC", onPressed: _onClearPress),
                RoundButton(text: "(", onPressed: () => _onOperandPress("(")),
                RoundButton(text: ")", onPressed: () => _onOperandPress(")")),
                RoundButton(text: "÷", onPressed: () => _onOperandPress("÷")),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                RoundButton(text: "7", onPressed: () => _updateInput("7")),
                RoundButton(text: "8", onPressed: () => _updateInput("8")),
                RoundButton(text: "9", onPressed: () => _updateInput("9")),
                RoundButton(text: "×", onPressed: () => _onOperandPress("×")),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                RoundButton(text: "4", onPressed: () => _updateInput("4")),
                RoundButton(text: "5", onPressed: () => _updateInput("5")),
                RoundButton(text: "6", onPressed: () => _updateInput("6")),
                RoundButton(text: "-", onPressed: () => _onOperandPress("-")),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                RoundButton(text: "1", onPressed: () => _updateInput("1")),
                RoundButton(text: "2", onPressed: () => _updateInput("2")),
                RoundButton(text: "3", onPressed: () => _updateInput("3")),
                RoundButton(text: "+", onPressed: () => _onOperandPress("+")),
              ],
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                RoundButton(text: ".", onPressed: _onDecimalPress),
                RoundButton(text: "0", onPressed: () => _updateInput("0")),
                RoundButton(text: "⌫", onPressed: _onDeletePress),
                RoundButton(text: "=", onPressed: _onEqualPress),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _updateInput(String input) {
    setState(() {
      _currentInput += input;
    });
  }

  void _onOperandPress(String operand) {
    setState(() {
      if (_currentInput.isNotEmpty) {
        _numbers.add(num.parse(_currentInput));
        _operations.add(operand);
        _currentInput = "";
      }
    });
  }

  void _onEqualPress() {
    setState(() {
      if (_currentInput.isNotEmpty) {
        _numbers.add(num.parse(_currentInput));
        _currentInput = "";
      }

      while (_operations.contains("(")) {
        int startIndex = _operations.lastIndexOf("(");
        int endIndex = _operations.indexOf(")", startIndex);
        List<num> numbersInsideParentheses = _numbers.sublist(startIndex, endIndex);
        List<String> operationsInsideParentheses = _operations.sublist(startIndex + 1, endIndex);

        processOperationsInsideParentheses(numbersInsideParentheses, operationsInsideParentheses);

        _numbers.replaceRange(startIndex, endIndex + 1, [numbersInsideParentheses.last]);
        _operations.removeRange(startIndex, endIndex + 1);
      }

      processOperation("^");

      processOperation("×");
      processOperation("÷");

      processOperation("+");
      processOperation("-");

      _output = _numbers[0].toString();
      _numbers.clear();
      _operations.clear();
    });
  }

  void _onClearPress() {
    setState(() {
      _output = "0";
      _currentInput = "";
      _numbers.clear();
      _operations.clear();
    });
  }

  void _onDeletePress() {
    setState(() {
      if (_currentInput.isNotEmpty) {
        _currentInput = _currentInput.substring(0, _currentInput.length - 1);
      } else if (_operations.isNotEmpty) {
        _operations.removeLast();
        _output = _numbers.last.toString();
        _numbers.removeLast();
      }
    });
  }

  void _onDecimalPress() {
    setState(() {
      if (!_currentInput.contains(".")) {
        _currentInput += ".";
      }
    });
  }

  void processOperation(String operator) {
    while (_operations.contains(operator)) {
      int index = _operations.indexOf(operator);
      num result = 0;

      if (operator == "×") {
        result = _numbers[index] * _numbers[index + 1];
      } else if (operator == "÷") {
        result = _numbers[index] / _numbers[index + 1];
      } else if (operator == "+") {
        result = _numbers[index] + _numbers[index + 1];
      } else if (operator == "-") {
        result = _numbers[index] - _numbers[index + 1];
      } else if (operator == "^") {
        result = 1;

        for (int i = 0; i < _numbers[index + 1]; i++) {
          result *= _numbers[index];
        }
      }

      _numbers.replaceRange(index, index + 2, [result]);
      _operations.removeAt(index);
    }
  }

  void processOperationsInsideParentheses(List<num> numbers, List<String> operations) {
    processOperationInsideParentheses("^", numbers, operations);
    processOperationInsideParentheses("×", numbers, operations);
    processOperationInsideParentheses("÷", numbers, operations);
    processOperationInsideParentheses("+", numbers, operations);
    processOperationInsideParentheses("-", numbers, operations);
  }

  void processOperationInsideParentheses(String operator, List<num> numbers, List<String> operations) {
    while (operations.contains(operator)) {
      int index = operations.indexOf(operator);
      num result = 0;
      if (operator == "×") {
        result = numbers[index] * numbers[index + 1];
      } else if (operator == "÷") {
        result = numbers[index] / numbers[index + 1];
      } else if (operator == "+") {
        result = numbers[index] + numbers[index + 1];
      } else if (operator == "-") {
        result = numbers[index] - numbers[index + 1];
      } else if (operator == "^") {
        result = 1;

        for (int i = 0; i < numbers[index + 1]; i++) {
          result *= numbers[index];
        }
      }

      numbers.replaceRange(index, index + 2, [result]);
      operations.removeAt(index);
    }
  }

  void _onConstantPress(String constant) {
    setState(() {
      if (constant == "e") {
        _currentInput += exp(1).toString();
      } else if (constant == "π") {
        _currentInput += pi.toString();
      }
    });
  }

  void _onFactorialPress() {
    setState(() {
      if (_currentInput.isNotEmpty) {
        int value = int.parse(_currentInput);
        int result = 1;
        for (int i = 1; i <= value; i++) {
          result *= i;
        }
        _currentInput = result.toString();
      }
    });
  }
}
