package com.example.calculator_jd

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
